import Card from '../ui/Card.jsx';
import styles from './DetailsCard.module.css';

export default function DetailsCard({ info }) {
  return (
    <Card eyebrow="Cuándo y dónde" title="Detalles de la celebración">
      <div className={styles.grid}>
        <div className={styles.item}>
          <div className={styles.label}>Fecha</div>
          <div className={styles.value}>{info.fechaDisplay}</div>
        </div>
        <div className={styles.item}>
          <div className={styles.label}>Hora</div>
          <div className={styles.value}>{info.hora}</div>
        </div>
        <div className={styles.item}>
          <div className={styles.label}>Lugar</div>
          <div className={styles.value}>{info.lugar}</div>
        </div>
        <div className={styles.item}>
          <div className={styles.label}>Ciudad</div>
          <div className={styles.value}>{info.ciudad}</div>
        </div>
      </div>

      {/* TODO: enlazar a Google Maps con las coordenadas reales del lugar */}
      <a className={styles.mapLink} href="#" onClick={(e) => e.preventDefault()}>
        Ver ubicación en el mapa →
      </a>

      <div className={styles.note}>
        <strong>Código de vestimenta:</strong> {info.vestimenta}
        <br />
        <strong>Restricciones:</strong> cuéntanos si tienes alguna alergia o preferencia alimenticia en el
        formulario.
      </div>
    </Card>
  );
}
