import styles from './DeclinedScenario.module.css';

export default function DeclinedScenario({ mensajePersonalizado }) {
  return (
    <div className={styles.card}>
      <div className={styles.script}>Te extrañaremos</div>
      <p>
        {mensajePersonalizado ||
          'Gracias por avisarnos. Sabemos que estarás con nosotros en pensamiento, y esperamos poder celebrar contigo pronto de otra forma.'}
        <br />
        <br />
        Con cariño,
        <br />
        Lenan &amp; Mauricio
      </p>
    </div>
  );
}
