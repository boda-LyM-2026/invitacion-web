import Card from '../ui/Card.jsx';
import { useCountdown } from './useCountdown.js';
import styles from './ConfirmedScenario.module.css';

export default function ConfirmedScenario({ info, mesa, asiento }) {
  const { d, h, m, s } = useCountdown(info.fechaISO);

  return (
    <>
      <Card eyebrow="Cuenta regresiva" title="Faltan...">
        <div className={styles.countdown}>
          <div className={styles.unit}>
            <div className={styles.num}>{d}</div>
            <div className={styles.lbl}>Días</div>
          </div>
          <div className={styles.unit}>
            <div className={styles.num}>{String(h).padStart(2, '0')}</div>
            <div className={styles.lbl}>Horas</div>
          </div>
          <div className={styles.unit}>
            <div className={styles.num}>{String(m).padStart(2, '0')}</div>
            <div className={styles.lbl}>Min</div>
          </div>
          <div className={styles.unit}>
            <div className={styles.num}>{String(s).padStart(2, '0')}</div>
            <div className={styles.lbl}>Seg</div>
          </div>
        </div>
      </Card>

      <Card eyebrow="Cronograma" title="Orden del día">
        <div className={styles.timeline}>
          {info.cronograma.map((row) => (
            <div className={styles.row} key={row.hora}>
              <div className={styles.time}>{row.hora}</div>
              <div className={styles.what}>{row.que}</div>
            </div>
          ))}
        </div>
      </Card>

      <Card eyebrow="Tu lugar" title="Ubicación asignada">
        <div className={styles.tableBlock}>
          <div>
            <div className={styles.tableNum}>Mesa {mesa}</div>
            <div className={styles.tableLabel}>Mesa</div>
          </div>
          <div>
            <div className={styles.tableNum}>{asiento}</div>
            <div className={styles.tableLabel}>Asiento</div>
          </div>
        </div>
        <div className={styles.note}>Recuerda: {info.vestimenta}</div>
      </Card>
    </>
  );
}
