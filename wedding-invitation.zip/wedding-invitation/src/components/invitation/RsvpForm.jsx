import { useState } from 'react';
import Card from '../ui/Card.jsx';
import styles from './RsvpForm.module.css';

export default function RsvpForm({ limitePersonas, onSubmit }) {
  const acompanantesCount = Math.max(0, limitePersonas - 1);

  const [titular, setTitular] = useState({ nombre: '', apellido: '', telefono: '' });
  const [asistira, setAsistira] = useState(true);
  const [acompanantes, setAcompanantes] = useState(
    Array.from({ length: acompanantesCount }, () => ({ nombre: '', apellido: '' }))
  );
  const [restricciones, setRestricciones] = useState('');
  const [sent, setSent] = useState(false);

  function updateAcompanante(index, field, value) {
    setAcompanantes((prev) => {
      const next = [...prev];
      next[index] = { ...next[index], [field]: value };
      return next;
    });
  }

  function handleSubmit() {
    // TODO: reemplazar por submitRsvp(groupId, payload) contra Supabase
    onSubmit?.({ titular, asistira, acompanantes, restricciones });
    setSent(true);
  }

  return (
    <Card eyebrow="RSVP" title="Confirma tu asistencia">
      <div className={styles.field}>
        <label htmlFor="fNombre">Nombre del titular</label>
        <input
          id="fNombre"
          type="text"
          placeholder="Tu nombre"
          value={titular.nombre}
          onChange={(e) => setTitular({ ...titular, nombre: e.target.value })}
        />
      </div>
      <div className={styles.field}>
        <label htmlFor="fApellido">Apellido</label>
        <input
          id="fApellido"
          type="text"
          placeholder="Tu apellido"
          value={titular.apellido}
          onChange={(e) => setTitular({ ...titular, apellido: e.target.value })}
        />
      </div>
      <div className={styles.field}>
        <label htmlFor="fTelefono">Teléfono</label>
        <input
          id="fTelefono"
          type="tel"
          placeholder="+591 ..."
          value={titular.telefono}
          onChange={(e) => setTitular({ ...titular, telefono: e.target.value })}
        />
      </div>

      <div className={styles.toggle}>
        <button type="button" className={asistira ? styles.active : ''} onClick={() => setAsistira(true)}>
          Asistiré
        </button>
        <button type="button" className={!asistira ? styles.active : ''} onClick={() => setAsistira(false)}>
          No podré asistir
        </button>
      </div>

      {asistira &&
        acompanantes.map((a, i) => (
          <div className={styles.guestBlock} key={i}>
            <span className={styles.guestLabel}>Acompañante {i + 1}</span>
            <div className={styles.field}>
              <label>Nombre</label>
              <input type="text" placeholder="Nombre" value={a.nombre} onChange={(e) => updateAcompanante(i, 'nombre', e.target.value)} />
            </div>
            <div className={styles.field}>
              <label>Apellido</label>
              <input type="text" placeholder="Apellido" value={a.apellido} onChange={(e) => updateAcompanante(i, 'apellido', e.target.value)} />
            </div>
          </div>
        ))}

      <div className={styles.field}>
        <label htmlFor="fRestric">Restricciones alimenticias</label>
        <textarea
          id="fRestric"
          rows={2}
          placeholder="Ej: vegetariano, sin gluten..."
          value={restricciones}
          onChange={(e) => setRestricciones(e.target.value)}
        />
      </div>

      <button className={styles.submit} onClick={handleSubmit}>
        Enviar confirmación
      </button>
      {sent && <p className={styles.confirmNote}>¡Gracias! Actualizaremos tu invitación en cuanto lo registremos.</p>}
    </Card>
  );
}
