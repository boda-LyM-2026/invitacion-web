import styles from './Hero.module.css';

const STATUS_LABEL = {
  pendiente: 'Confirmación pendiente',
  confirmado: 'Asistencia confirmada',
  rechazado: 'No podrá asistir'
};

export default function Hero({ coupleNames, status }) {
  const [nombre1, nombre2] = coupleNames.split('&').map((s) => s.trim());

  return (
    <div className={styles.hero}>
      <span className={`eyebrow ${styles.heroEyebrow}`}>Boda</span>
      <h1 className={styles.names}>
        {nombre1} <span className={styles.amp}>&amp;</span> {nombre2}
      </h1>

      <svg className={styles.branch} viewBox="0 0 120 24" fill="none" stroke="currentColor" strokeWidth="1.2">
        <path d="M2 12 C 30 2, 90 22, 118 12" />
        <path d="M20 9 q6 -8 10 0" />
        <path d="M45 15 q6 8 10 0" />
        <path d="M70 9 q6 -8 10 0" />
        <path d="M95 15 q6 8 10 0" />
      </svg>

      <p className={styles.lede}>
        Con la bendición de nuestros padres, nos casamos y queremos que seas parte de este día.
      </p>

      <div className={styles.pill}>
        <span className={styles.dot} />
        <span>{STATUS_LABEL[status]}</span>
      </div>
    </div>
  );
}
