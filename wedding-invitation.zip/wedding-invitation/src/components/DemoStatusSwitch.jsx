import styles from './DemoStatusSwitch.module.css';

// Solo para desarrollo local: una vez que el estado venga de Supabase
// (estados_invitacion vía el token del grupo), este componente se elimina.
const OPTIONS = [
  { value: 'pendiente', label: 'Pendiente' },
  { value: 'confirmado', label: 'Confirmado' },
  { value: 'rechazado', label: 'Rechazado' }
];

export default function DemoStatusSwitch({ status, onChange }) {
  return (
    <div className={styles.switch}>
      {OPTIONS.map((opt) => (
        <button
          key={opt.value}
          className={status === opt.value ? styles.active : ''}
          onClick={() => onChange(opt.value)}
        >
          {opt.label}
        </button>
      ))}
    </div>
  );
}
