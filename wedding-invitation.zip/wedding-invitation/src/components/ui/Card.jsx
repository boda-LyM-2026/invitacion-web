import styles from './Card.module.css';

export default function Card({ eyebrow, title, children }) {
  return (
    <div className={styles.card}>
      {eyebrow && <span className="eyebrow" style={{ textAlign: 'center', marginBottom: 8 }}>{eyebrow}</span>}
      {title && <h2 className={styles.title}>{title}</h2>}
      {children}
    </div>
  );
}
