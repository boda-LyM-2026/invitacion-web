import { motion } from 'framer-motion';
import styles from './Envelope.module.css';

const EASE = [0.6, 0.05, 0.2, 1];

/**
 * Escenas 1-2-5-6 de la intro: sobre cerrado -> ligera inclinación 3D ->
 * la solapa se abre -> la carta asoma. `scene` viene orquestado desde
 * IntroSequence.
 */
export default function Envelope({ scene, coupleNames = 'Lenan & Mauricio' }) {
  const tilted = scene !== 'closed';
  const flapOpen = scene === 'opening' || scene === 'letter';
  const letterUp = scene === 'letter';
  const letterPeek = scene === 'opening';

  return (
    <motion.div
      className={styles.envelope}
      animate={{
        rotateY: tilted ? -8 : 0,
        rotateX: tilted ? 6 : 0,
        scale: tilted ? 1.03 : 1
      }}
      transition={{ duration: 1.1, ease: EASE }}
      style={{ transformStyle: 'preserve-3d' }}
    >
      <svg className={styles.body} viewBox="0 0 380 250">
        <rect x="2" y="2" width="376" height="246" rx="4" fill="#F1F0E8" stroke="#93A27D" strokeOpacity=".5" />
        <polyline points="2,4 190,150 378,4" fill="none" stroke="#93A27D" strokeOpacity=".4" strokeWidth="1.5" />
      </svg>

      <div className={styles.monogramWrap}>
        <div className={styles.monogramScript}>{coupleNames}</div>
        <div className={styles.monogramSub}>Nos casamos</div>
      </div>

      <motion.div
        className={styles.flapGroup}
        animate={{ rotateX: flapOpen ? 178 : 0 }}
        transition={{ duration: 1.15, ease: EASE }}
        style={{ transformOrigin: '50% 0%' }}
      >
        <svg className={styles.bodyFlat} viewBox="0 0 380 250">
          <polygon points="2,4 190,150 378,4" fill="#EBE3D5" stroke="#93A27D" strokeOpacity=".5" />
        </svg>
      </motion.div>

      <motion.div
        className={styles.letterCard}
        animate={{
          opacity: letterPeek || letterUp ? 1 : 0,
          y: letterUp ? -320 : letterPeek ? -46 : 0,
          scale: letterUp ? 1.06 : 1
        }}
        transition={{ duration: letterUp ? 1.1 : 0.9, ease: [0.2, 0.7, 0.2, 1] }}
      >
        <div className={styles.letterScript}>{coupleNames}</div>
        <div className={styles.letterFine}>Con todo nuestro cariño te invitamos</div>
      </motion.div>
    </motion.div>
  );
}
