import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Envelope from './Envelope.jsx';
import WaxSeal from './WaxSeal.jsx';
import styles from './IntroSequence.module.css';

// Escenas 1→6 del RF-04: closed, tilt, seal, breaking, opening, letter.
// Cuando termina, avisa al padre vía onComplete() para mostrar la invitación.
export default function IntroSequence({ coupleNames, onComplete }) {
  const [scene, setScene] = useState('closed');
  const [hidden, setHidden] = useState(false);

  function handleEnvelopeClick() {
    if (scene !== 'closed') return;
    setScene('tilt');
    setTimeout(() => setScene('seal'), 700);
  }

  function handleSealBreak() {
    setScene('breaking');
    setTimeout(() => setScene('opening'), 550);
    setTimeout(() => setScene('letter'), 1500);
    setTimeout(() => {
      setHidden(true);
      onComplete();
    }, 2500);
  }

  return (
    <AnimatePresence>
      {!hidden && (
        <motion.div
          className={styles.stage}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.9 }}
        >
          <div className={styles.envelopeWrap} onClick={handleEnvelopeClick}>
            <Envelope scene={scene} coupleNames={coupleNames} />
            <WaxSeal scene={scene} onBreak={handleSealBreak} />
          </div>
          {scene === 'closed' && <p className={styles.hint}>Toca el sobre para abrirlo</p>}
        </motion.div>
      )}
    </AnimatePresence>
  );
}
