import { motion } from 'framer-motion';
import styles from './WaxSeal.module.css';

/**
 * Escenas 3-4: el sello aparece (pulso) y, al tocarlo, se parte en dos mitades.
 */
export default function WaxSeal({ scene, onBreak }) {
  const visible = scene === 'seal' || scene === 'breaking';
  const breaking = scene === 'breaking';
  const pulsing = scene === 'seal';

  return (
    <motion.div
      className={styles.seal}
      animate={{ opacity: visible ? 1 : 0, scale: visible ? 1 : 0.6 }}
      transition={{ duration: 0.5 }}
      style={{ pointerEvents: scene === 'seal' ? 'auto' : 'none' }}
      onClick={() => scene === 'seal' && onBreak()}
    >
      <motion.div
        className={`${styles.disc} ${styles.left}`}
        animate={
          breaking
            ? { x: -14, y: -6, rotate: -18 }
            : { x: 0, y: 0, rotate: 0, scale: pulsing ? [1, 1.05, 1] : 1 }
        }
        transition={
          pulsing
            ? { duration: 1.8, repeat: Infinity, ease: 'easeInOut' }
            : { duration: 0.5, ease: [0.6, 0.1, 0.3, 1] }
        }
      />
      <motion.div
        className={`${styles.disc} ${styles.right}`}
        animate={
          breaking
            ? { x: 14, y: 6, rotate: 18 }
            : { x: 0, y: 0, rotate: 0, scale: pulsing ? [1, 1.05, 1] : 1 }
        }
        transition={
          pulsing
            ? { duration: 1.8, repeat: Infinity, ease: 'easeInOut' }
            : { duration: 0.5, ease: [0.6, 0.1, 0.3, 1] }
        }
      />
      <motion.div className={styles.heart} animate={{ opacity: breaking ? 0 : 1 }}>
        ♥
      </motion.div>
    </motion.div>
  );
}
