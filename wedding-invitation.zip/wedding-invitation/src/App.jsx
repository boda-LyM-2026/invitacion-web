import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import InvitationPage from './pages/InvitationPage.jsx';

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/invitacion/:token" element={<InvitationPage />} />
        {/* Redirección de conveniencia para probar en local sin token real */}
        <Route path="/" element={<Navigate to="/invitacion/demo-token" replace />} />
        <Route path="*" element={<Navigate to="/invitacion/demo-token" replace />} />
      </Routes>
    </BrowserRouter>
  );
}
