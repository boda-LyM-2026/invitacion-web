import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import IntroSequence from '../components/intro/IntroSequence.jsx';
import Hero from '../components/invitation/Hero.jsx';
import DetailsCard from '../components/invitation/DetailsCard.jsx';
import RsvpForm from '../components/invitation/RsvpForm.jsx';
import ConfirmedScenario from '../components/invitation/ConfirmedScenario.jsx';
import DeclinedScenario from '../components/invitation/DeclinedScenario.jsx';
import DemoStatusSwitch from '../components/DemoStatusSwitch.jsx';
import { mockGuestGroup, weddingInfo } from '../data/mockGuestGroup.js';
// import { getInvitationByToken, submitRsvp } from '../lib/supabaseClient.js';
import styles from './InvitationPage.module.css';

const COUPLE_NAMES = 'Lenan & Mauricio';

export default function InvitationPage() {
  const { token } = useParams();

  const [introDone, setIntroDone] = useState(false);
  const [guestGroup, setGuestGroup] = useState(mockGuestGroup);
  const [loading, setLoading] = useState(false); // pasará a true cuando se conecte Supabase
  const [error, setError] = useState(null);

  useEffect(() => {
    // TODO: reemplazar el mock por la carga real.
    // setLoading(true);
    // getInvitationByToken(token)
    //   .then(setGuestGroup)
    //   .catch((e) => setError(e.message))
    //   .finally(() => setLoading(false));
  }, [token]);

  function handleRsvpSubmit(payload) {
    // TODO: submitRsvp(guestGroup.id, payload)
    console.log('RSVP recibido (pendiente de enviar a Supabase):', payload);
  }

  function handleDemoStatusChange(nombre) {
    setGuestGroup((prev) => ({ ...prev, estado_general: { ...prev.estado_general, nombre } }));
  }

  if (loading) return <div className={styles.centered}>Cargando invitación...</div>;
  if (error) return <div className={styles.centered}>No pudimos cargar esta invitación: {error}</div>;

  const status = guestGroup.estado_general.nombre;
  const titular = guestGroup.invitados.find((g) => g.es_titular);

  return (
    <>
      {!introDone && <IntroSequence coupleNames={COUPLE_NAMES} onComplete={() => setIntroDone(true)} />}

      {introDone && (
        <main className={styles.invitation}>
          <Hero coupleNames={COUPLE_NAMES} status={status} />

          {status === 'pendiente' && (
            <>
              <DetailsCard info={weddingInfo} />
              <RsvpForm limitePersonas={guestGroup.limite_personas} onSubmit={handleRsvpSubmit} />
            </>
          )}

          {status === 'confirmado' && (
            <ConfirmedScenario info={weddingInfo} mesa={titular?.mesa ?? 3} asiento={titular?.asiento ?? 'A2'} />
          )}

          {status === 'rechazado' && <DeclinedScenario mensajePersonalizado={guestGroup.mensaje_personalizado} />}

          <p className={styles.footer}>{COUPLE_NAMES} · {weddingInfo.fechaDisplay.replace('nov', 'de noviembre de')}</p>
        </main>
      )}

      {import.meta.env.DEV && introDone && <DemoStatusSwitch status={status} onChange={handleDemoStatusChange} />}
    </>
  );
}
