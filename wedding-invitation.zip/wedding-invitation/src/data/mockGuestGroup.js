// Simula la fila de `grupos_invitacion` + sus `invitados`, tal como la
// traerá luego src/lib/supabaseClient.js -> getInvitationByToken().
// Bórralo cuando el fetch real esté conectado en App.jsx.

export const mockGuestGroup = {
  id: 'mock-group-id',
  token_unico: 'demo-token',
  nombre_sobre: 'Familia Pérez',
  limite_personas: 3,
  estado_general: {
    id: 1,
    nombre: 'pendiente' // 'pendiente' | 'confirmado' | 'rechazado'
  },
  mensaje_personalizado: null,
  invitados: [
    { id: 'g1', nombre: '', apellido: '', es_titular: true, mesa: null, asiento: null }
  ]
};

export const weddingInfo = {
  novios: { el: 'Mauricio', ella: 'Lenan' },
  fechaISO: '2026-11-15T17:30:00',
  fechaDisplay: '15 nov 2026',
  hora: '17:30 h',
  lugar: 'Jardín Olivo',
  ciudad: 'Cochabamba',
  vestimenta: 'Formal, tonos tierra y verdes bienvenidos. Evitar blanco.',
  cronograma: [
    { hora: '17:30', que: 'Ceremonia religiosa' },
    { hora: '18:30', que: 'Cóctel de bienvenida' },
    { hora: '20:00', que: 'Cena y brindis' },
    { hora: '21:30', que: 'Fiesta' }
  ]
};
