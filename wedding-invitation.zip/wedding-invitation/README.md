# Invitación — Lenan & Mauricio

Proyecto React (Vite) para la invitación de boda pública. Backend en Supabase (ver `db/` o el script que ya tienes).

## Cómo correrlo

```bash
npm install
npm run dev
```

Abre `http://localhost:5173/invitacion/demo-token` (o simplemente `http://localhost:5173/`, redirige ahí).

## Estructura

```
src/
  components/
    intro/        -> secuencia cinemática (sobre, sello de cera)
    invitation/    -> hero, detalles, RSVP, escenario confirmado/rechazado
    ui/            -> piezas compartidas (Card)
    DemoStatusSwitch.jsx -> SOLO desarrollo, para alternar entre los 3 escenarios
  pages/
    InvitationPage.jsx -> arma la página según /invitacion/:token
  data/
    mockGuestGroup.js  -> datos de ejemplo mientras no está Supabase conectado
  lib/
    supabaseClient.js  -> cliente + funciones stub (getInvitationByToken, submitRsvp)
  styles/
    tokens.css   -> paleta, tipografía, radios, sombras (variables CSS globales)
    global.css   -> reset y estilos base
```

## Estado actual

- ✅ Intro cinemática de 6 escenas (sobre → giro 3D → sello → rotura → apertura → carta) con Framer Motion.
- ✅ Los 3 escenarios de RSVP (pendiente / confirmado / rechazado) con datos de ejemplo.
- ✅ Formulario RSVP con campos de acompañantes dinámicos según `limite_personas`.
- ⏳ Conexión real a Supabase: los TODO están marcados en `src/lib/supabaseClient.js` y `src/pages/InvitationPage.jsx`.
- ⏳ Dashboard administrativo (RF-08 a RF-12): todavía no existe, es el siguiente módulo.
- 🧪 `DemoStatusSwitch` es temporal — bórralo cuando el estado venga real de Supabase.

## Siguiente paso: conectar Supabase

1. Copia `.env.example` a `.env` y llena `VITE_SUPABASE_URL` / `VITE_SUPABASE_ANON_KEY`.
2. Implementa `getInvitationByToken` en `src/lib/supabaseClient.js` (la consulta de ejemplo ya está comentada ahí).
3. En `InvitationPage.jsx`, descomenta el `useEffect` que llama a `getInvitationByToken(token)` y quita `mockGuestGroup`.
4. Implementa `submitRsvp` para que el formulario escriba en `invitados` / `grupos_invitacion`.

## Paleta y tipografía

- Champagne `#EBE3D5`, Alabaster `#F1F0E8`, Pistachio `#93A27D` (principal), Dusty Sage `#7C8B65`, Olive `#616E4D`.
- Tipografías: Cormorant Garamond (cuerpo/títulos), Parisienne (script, nombres), Jost (etiquetas UI).
- Todo vive como variables CSS en `src/styles/tokens.css` — cambia ahí, no en los componentes.
